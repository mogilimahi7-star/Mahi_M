import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  CalendarCheck, 
  Calendar,
  GraduationCap, 
  CreditCard, 
  Clock, 
  FileText, 
  LogOut, 
  Plus, 
  Search, 
  Trash2, 
  Edit2,
  ChevronRight,
  UserCircle,
  Menu,
  X,
  Check,
  AlertCircle,
  Filter,
  MoreVertical
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn, Student, Attendance, Mark, Fee, TimetableEntry, User } from './types';
import { format } from 'date-fns';

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) => (
  <button
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group",
      active 
        ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200" 
        : "text-slate-600 hover:bg-indigo-50 hover:text-indigo-600"
    )}
  >
    <Icon size={20} className={cn("transition-transform duration-200", active ? "scale-110" : "group-hover:scale-110")} />
    <span className="font-medium">{label}</span>
  </button>
);

const Card = ({ children, className }: { children: React.ReactNode, className?: string }) => (
  <div className={cn("bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden", className)}>
    {children}
  </div>
);

const Button = ({ children, onClick, variant = 'primary', className, disabled, type = 'button' }: { children: React.ReactNode, onClick?: () => void, variant?: 'primary' | 'secondary' | 'danger', className?: string, disabled?: boolean, type?: 'button' | 'submit' | 'reset' }) => {
  const variants = {
    primary: "bg-indigo-600 text-white hover:bg-indigo-700 shadow-indigo-100",
    secondary: "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50",
    danger: "bg-rose-500 text-white hover:bg-rose-600 shadow-rose-100"
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed",
        variants[variant],
        className
      )}
    >
      {children}
    </button>
  );
};

const Input = ({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) => (
  <div className="space-y-1.5">
    <label className="text-sm font-semibold text-slate-700">{label}</label>
    <input
      {...props}
      className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none bg-slate-50/50"
    />
  </div>
);

const Select = ({ label, options, ...props }: { label: string, options: { value: string, label: string }[] } & React.SelectHTMLAttributes<HTMLSelectElement>) => (
  <div className="space-y-1.5">
    <label className="text-sm font-semibold text-slate-700">{label}</label>
    <select
      {...props}
      className="w-full px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all outline-none bg-slate-50/50"
    >
      {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
    </select>
  </div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Auth State
  const [isRegistering, setIsRegistering] = useState(false);
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const [loginError, setLoginError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Data States
  const [stats, setStats] = useState({ totalStudents: 0, totalFees: 0, recentAttendance: 0 });
  const [students, setStudents] = useState<Student[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [fees, setFees] = useState<Fee[]>([]);
  const [loading, setLoading] = useState(false);

  // Modal States
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [studentToDelete, setStudentToDelete] = useState<number | null>(null);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [studentFormData, setStudentFormData] = useState({
    student_id: '',
    name: '',
    email: '',
    phone: '',
    dob: '',
    gender: 'Male',
    address: '',
    class: '',
    section: '',
    enrollment_date: format(new Date(), 'yyyy-MM-dd')
  });

  useEffect(() => {
    if (token) {
      fetchStats();
      fetchStudents();
    }
  }, [token]);

  const fetchStats = async () => {
    const res = await fetch('/api/stats', { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setStats(await res.json());
  };

  const fetchStudents = async () => {
    setLoading(true);
    const res = await fetch('/api/students', { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setStudents(await res.json());
    setLoading(false);
  };

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    const method = editingStudent ? 'PUT' : 'POST';
    const url = editingStudent ? `/api/students/${editingStudent.id}` : '/api/students';
    
    const res = await fetch(url, {
      method,
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(studentFormData)
    });

    if (res.ok) {
      setIsStudentModalOpen(false);
      setEditingStudent(null);
      setStudentFormData({
        student_id: '', name: '', email: '', phone: '', dob: '',
        gender: 'Male', address: '', class: '', section: '',
        enrollment_date: format(new Date(), 'yyyy-MM-dd')
      });
      fetchStudents();
      fetchStats();
    } else {
      const err = await res.json();
      alert(err.message || 'Failed to save student');
    }
  };

  const handleDeleteStudent = async () => {
    if (!studentToDelete) return;
    const res = await fetch(`/api/students/${studentToDelete}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (res.ok) {
      setIsDeleteModalOpen(false);
      setStudentToDelete(null);
      fetchStudents();
      fetchStats();
    }
  };

  const [attendanceDate, setAttendanceDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [attendanceRecords, setAttendanceRecords] = useState<Record<number, 'Present' | 'Absent' | 'Late'>>({});

  useEffect(() => {
    if (token && activeTab === 'attendance') {
      fetchAttendance();
    }
  }, [token, activeTab, attendanceDate]);

  const fetchAttendance = async () => {
    const res = await fetch(`/api/attendance?date=${attendanceDate}`, { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) {
      const data: Attendance[] = await res.json();
      const records: Record<number, 'Present' | 'Absent' | 'Late'> = {};
      data.forEach(rec => {
        records[rec.student_id] = rec.status;
      });
      setAttendanceRecords(records);
    }
  };

  const handleSaveAttendance = async () => {
    const records = Object.entries(attendanceRecords).map(([student_id, status]) => ({
      student_id: parseInt(student_id),
      status
    }));

    const res = await fetch('/api/attendance', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ records, date: attendanceDate })
    });

    if (res.ok) {
      alert('Attendance saved successfully');
      fetchStats();
    }
  };

  const [isFeeModalOpen, setIsFeeModalOpen] = useState(false);
  const [feeFormData, setFeeFormData] = useState({
    student_id: 0,
    amount: 0,
    status: 'Pending' as const,
    payment_date: '',
    description: 'Tuition Fee'
  });

  useEffect(() => {
    if (token && activeTab === 'fees') {
      fetchFees();
    }
  }, [token, activeTab]);

  const fetchFees = async () => {
    const res = await fetch('/api/fees', { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setFees(await res.json());
  };

  const handleAddFee = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/fees', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(feeFormData)
    });

    if (res.ok) {
      setIsFeeModalOpen(false);
      fetchFees();
      fetchStats();
    }
  };

  const [isMarkModalOpen, setIsMarkModalOpen] = useState(false);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [markFormData, setMarkFormData] = useState({
    student_id: 0,
    subject: '',
    exam_type: 'Final',
    marks_obtained: 0,
    total_marks: 100,
    date: format(new Date(), 'yyyy-MM-dd')
  });

  const fetchMarks = async (studentId: number) => {
    const res = await fetch(`/api/marks/${studentId}`, { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setMarks(await res.json());
  };

  const handleAddMark = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/marks', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(markFormData)
    });

    if (res.ok) {
      setIsMarkModalOpen(false);
      fetchMarks(markFormData.student_id);
    }
  };

  const [timetable, setTimetable] = useState<TimetableEntry[]>([]);
  const [isTimetableModalOpen, setIsTimetableModalOpen] = useState(false);
  const [timetableFormData, setTimetableFormData] = useState({
    class: 'Class 10',
    subject: '',
    day: 'Monday',
    start_time: '09:00',
    end_time: '10:00',
    teacher: ''
  });

  const fetchTimetable = async (className: string) => {
    const res = await fetch(`/api/timetable/${className}`, { headers: { 'Authorization': `Bearer ${token}` } });
    if (res.ok) setTimetable(await res.json());
  };

  const handleAddTimetable = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/timetable', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(timetableFormData)
    });

    if (res.ok) {
      setIsTimetableModalOpen(false);
      fetchTimetable(timetableFormData.class);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setSuccessMsg('');
    
    const endpoint = isRegistering ? '/api/register' : '/api/login';
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(loginData)
    });
    
    if (res.ok) {
      const data = await res.json();
      if (isRegistering) {
        setSuccessMsg('Registration successful! Please login.');
        setIsRegistering(false);
        setLoginData({ username: '', password: '' });
      } else {
        setToken(data.token);
        setUser(data.user);
        localStorage.setItem('token', data.token);
      }
    } else {
      const error = await res.json();
      setLoginError(error.message || 'Authentication failed');
    }
  };

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <Card className="p-8">
            <div className="flex flex-col items-center mb-8">
              <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white mb-4 shadow-xl shadow-indigo-100">
                <GraduationCap size={32} />
              </div>
              <h1 className="text-2xl font-bold text-slate-900">EduTrack Pro</h1>
              <p className="text-slate-500">{isRegistering ? 'Create your account' : 'Student Management System'}</p>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              <Input 
                label="Username" 
                placeholder="Choose a username"
                value={loginData.username}
                onChange={e => setLoginData({...loginData, username: e.target.value})}
                required
              />
              <Input 
                label="Password" 
                type="password" 
                placeholder="••••••••"
                value={loginData.password}
                onChange={e => setLoginData({...loginData, password: e.target.value})}
                required
              />
              {loginError && <p className="text-rose-500 text-sm font-medium">{loginError}</p>}
              {successMsg && <p className="text-emerald-500 text-sm font-medium">{successMsg}</p>}
              <Button className="w-full py-3 mt-2">
                {isRegistering ? 'Create Account' : 'Sign In'}
              </Button>
            </form>
            
            <div className="mt-6 text-center">
              <button 
                onClick={() => {
                  setIsRegistering(!isRegistering);
                  setLoginError('');
                  setSuccessMsg('');
                }}
                className="text-indigo-600 font-semibold hover:underline text-sm"
              >
                {isRegistering ? 'Already have an account? Sign In' : "Don't have an account? Register Now"}
              </button>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-100 text-center">
              <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">System Access</p>
              <p className="text-sm text-slate-600 mt-2">Authorized Personnel Only</p>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 transition-transform duration-300 lg:translate-x-0 lg:static",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-full flex flex-col p-4">
          <div className="flex items-center gap-3 px-2 mb-8">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
              <GraduationCap size={24} />
            </div>
            <span className="text-xl font-bold text-slate-900">EduTrack</span>
          </div>

          <nav className="flex-1 space-y-1">
            <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
            <SidebarItem icon={Users} label="Students" active={activeTab === 'students'} onClick={() => setActiveTab('students')} />
            <SidebarItem icon={CalendarCheck} label="Attendance" active={activeTab === 'attendance'} onClick={() => setActiveTab('attendance')} />
            <SidebarItem icon={GraduationCap} label="Marks & Results" active={activeTab === 'marks'} onClick={() => setActiveTab('marks')} />
            <SidebarItem icon={CreditCard} label="Fee Management" active={activeTab === 'fees'} onClick={() => setActiveTab('fees')} />
            <SidebarItem icon={Clock} label="Timetable" active={activeTab === 'timetable'} onClick={() => setActiveTab('timetable')} />
            <SidebarItem icon={FileText} label="Reports" active={activeTab === 'reports'} onClick={() => setActiveTab('reports')} />
          </nav>

          <div className="pt-4 border-t border-slate-100">
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-rose-50 hover:text-rose-600 rounded-lg transition-colors"
            >
              <LogOut size={20} />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-40">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="lg:hidden p-2 text-slate-600">
            {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          
          <div className="flex items-center gap-4 ml-auto">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-bold text-slate-900">Administrator</p>
              <p className="text-xs text-slate-500">Super Admin</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 border border-slate-200">
              <UserCircle size={24} />
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="p-4 lg:p-8 overflow-auto">
          <AnimatePresence>
            {isStudentModalOpen && (
              <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="w-full max-w-2xl"
                >
                  <Card className="p-6 max-h-[90vh] overflow-y-auto">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xl font-bold text-slate-900">
                        {editingStudent ? 'Edit Student Details' : 'Register New Student'}
                      </h3>
                      <button onClick={() => setIsStudentModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600">
                        <X size={20} />
                      </button>
                    </div>

                    <form onSubmit={handleAddStudent} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input 
                        label="Student ID" 
                        placeholder="e.g. S1001" 
                        value={studentFormData.student_id}
                        onChange={e => setStudentFormData({...studentFormData, student_id: e.target.value})}
                        required
                      />
                      <Input 
                        label="Full Name" 
                        placeholder="John Doe" 
                        value={studentFormData.name}
                        onChange={e => setStudentFormData({...studentFormData, name: e.target.value})}
                        required
                      />
                      <Input 
                        label="Email" 
                        type="email" 
                        placeholder="john@example.com" 
                        value={studentFormData.email}
                        onChange={e => setStudentFormData({...studentFormData, email: e.target.value})}
                        required
                      />
                      <Input 
                        label="Phone" 
                        placeholder="1234567890" 
                        value={studentFormData.phone}
                        onChange={e => setStudentFormData({...studentFormData, phone: e.target.value})}
                        required
                      />
                      <Input 
                        label="Date of Birth" 
                        type="date" 
                        value={studentFormData.dob}
                        onChange={e => setStudentFormData({...studentFormData, dob: e.target.value})}
                        required
                      />
                      <Select 
                        label="Gender" 
                        options={[{value: 'Male', label: 'Male'}, {value: 'Female', label: 'Female'}, {value: 'Other', label: 'Other'}]} 
                        value={studentFormData.gender}
                        onChange={e => setStudentFormData({...studentFormData, gender: e.target.value})}
                      />
                      <Input 
                        label="Class" 
                        placeholder="10" 
                        value={studentFormData.class}
                        onChange={e => setStudentFormData({...studentFormData, class: e.target.value})}
                        required
                      />
                      <Input 
                        label="Section" 
                        placeholder="A" 
                        value={studentFormData.section}
                        onChange={e => setStudentFormData({...studentFormData, section: e.target.value})}
                        required
                      />
                      <div className="md:col-span-2">
                        <Input 
                          label="Address" 
                          placeholder="123 Street Name, City" 
                          value={studentFormData.address}
                          onChange={e => setStudentFormData({...studentFormData, address: e.target.value})}
                          required
                        />
                      </div>
                      <div className="md:col-span-2 flex justify-end gap-3 mt-4">
                        <Button variant="secondary" type="button" onClick={() => setIsStudentModalOpen(false)}>Cancel</Button>
                        <Button type="submit">{editingStudent ? 'Update Details' : 'Save Student'}</Button>
                      </div>
                    </form>
                  </Card>
                </motion.div>
              </div>
            )}

            {isDeleteModalOpen && (
              <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="w-full max-w-md"
                >
                  <Card className="p-6">
                    <div className="flex items-center gap-4 text-rose-600 mb-4">
                      <div className="p-3 bg-rose-100 rounded-xl">
                        <AlertCircle size={24} />
                      </div>
                      <h3 className="text-xl font-bold">Confirm Deletion</h3>
                    </div>
                    <p className="text-slate-600 mb-6">
                      Are you sure you want to delete this student? This action cannot be undone and all associated records will be lost.
                    </p>
                    <div className="flex justify-end gap-3">
                      <Button variant="secondary" onClick={() => {
                        setIsDeleteModalOpen(false);
                        setStudentToDelete(null);
                      }}>
                        Cancel
                      </Button>
                      <Button variant="danger" onClick={handleDeleteStudent}>
                        Delete Permanently
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              </div>
            )}
          </AnimatePresence>

          <AnimatePresence mode="wait">
            {activeTab === 'dashboard' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="p-6 bg-gradient-to-br from-indigo-600 to-indigo-700 text-white border-none">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-indigo-100 font-medium">Total Students</p>
                        <h3 className="text-4xl font-bold mt-1">{stats.totalStudents}</h3>
                      </div>
                      <div className="p-3 bg-white/10 rounded-xl backdrop-blur-sm">
                        <Users size={24} />
                      </div>
                    </div>
                  </Card>
                  <Card className="p-6 bg-white">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-slate-500 font-medium">Fees Collected</p>
                        <h3 className="text-4xl font-bold mt-1 text-slate-900">${stats.totalFees}</h3>
                      </div>
                      <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                        <CreditCard size={24} />
                      </div>
                    </div>
                  </Card>
                  <Card className="p-6 bg-white">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-slate-500 font-medium">Today's Attendance</p>
                        <h3 className="text-4xl font-bold mt-1 text-slate-900">{stats.recentAttendance}</h3>
                      </div>
                      <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
                        <CalendarCheck size={24} />
                      </div>
                    </div>
                  </Card>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <Card className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h4 className="text-lg font-bold text-slate-900">Recent Students</h4>
                      <Button variant="secondary" onClick={() => setActiveTab('students')}>View All</Button>
                    </div>
                    <div className="space-y-4">
                      {students.slice(0, 5).map(student => (
                        <div key={student.id} className="flex items-center gap-4 p-3 hover:bg-slate-50 rounded-lg transition-colors">
                          <div className="w-10 h-10 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 font-bold">
                            {student.name.charAt(0)}
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold text-slate-900">{student.name}</p>
                            <p className="text-xs text-slate-500">{student.student_id} • {student.class} {student.section}</p>
                          </div>
                          <ChevronRight size={16} className="text-slate-400" />
                        </div>
                      ))}
                    </div>
                  </Card>
                  
                  <Card className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h4 className="text-lg font-bold text-slate-900">Quick Actions</h4>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <button onClick={() => setActiveTab('students')} className="p-4 rounded-xl border border-slate-200 hover:border-indigo-600 hover:bg-indigo-50 transition-all text-left group">
                        <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-lg flex items-center justify-center mb-3 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                          <Plus size={20} />
                        </div>
                        <p className="font-bold text-slate-900">Add Student</p>
                        <p className="text-xs text-slate-500">Register new student</p>
                      </button>
                      <button onClick={() => setActiveTab('attendance')} className="p-4 rounded-xl border border-slate-200 hover:border-amber-600 hover:bg-amber-50 transition-all text-left group">
                        <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-lg flex items-center justify-center mb-3 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                          <CalendarCheck size={20} />
                        </div>
                        <p className="font-bold text-slate-900">Attendance</p>
                        <p className="text-xs text-slate-500">Mark daily attendance</p>
                      </button>
                    </div>
                  </Card>
                </div>
              </motion.div>
            )}

            {activeTab === 'students' && (
              <motion.div 
                key="students"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Student Directory</h2>
                    <p className="text-slate-500">Manage and view all student records</p>
                  </div>
                  <Button onClick={() => {
                    setEditingStudent(null);
                    setStudentFormData({
                      student_id: '', name: '', email: '', phone: '', dob: '',
                      gender: 'Male', address: '', class: '', section: '',
                      enrollment_date: format(new Date(), 'yyyy-MM-dd')
                    });
                    setIsStudentModalOpen(true);
                  }} className="sm:w-auto">
                    <Plus size={20} />
                    Add New Student
                  </Button>
                </div>

                <Card>
                  <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row gap-4">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" 
                        placeholder="Search by name or ID..." 
                        className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Select label="" options={[{value: 'all', label: 'All Classes'}, {value: '10', label: 'Class 10'}]} className="py-2" />
                    </div>
                  </div>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 border-b border-slate-100">
                        <tr>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Student</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">ID</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Class</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Contact</th>
                          <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {students.map(student => (
                          <tr key={student.id} className="hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xs">
                                  {student.name.charAt(0)}
                                </div>
                                <span className="font-semibold text-slate-900">{student.name}</span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-slate-600 font-mono text-sm">{student.student_id}</td>
                            <td className="px-6 py-4">
                              <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                                {student.class} - {student.section}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-600">{student.phone}</td>
                            <td className="px-6 py-4 text-right">
                              <div className="flex justify-end gap-2">
                                <button 
                                  onClick={() => {
                                    setEditingStudent(student);
                                    setStudentFormData({
                                      student_id: student.student_id,
                                      name: student.name,
                                      email: student.email,
                                      phone: student.phone,
                                      dob: student.dob,
                                      gender: student.gender,
                                      address: student.address,
                                      class: student.class,
                                      section: student.section,
                                      enrollment_date: student.enrollment_date
                                    });
                                    setIsStudentModalOpen(true);
                                  }}
                                  className="p-2 text-slate-400 hover:text-indigo-600 transition-colors"
                                  title="Edit Student"
                                >
                                  <Edit2 size={18} />
                                </button>
                                <button 
                                  onClick={() => {
                                    setStudentToDelete(student.id);
                                    setIsDeleteModalOpen(true);
                                  }}
                                  className="p-2 text-slate-400 hover:text-rose-600 transition-colors"
                                  title="Delete Student"
                                >
                                  <Trash2 size={18} />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </Card>
              </motion.div>
            )}

            {activeTab === 'attendance' && (
              <motion.div 
                key="attendance"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Attendance Tracker</h2>
                    <p className="text-slate-500">Record daily student presence</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <input 
                      type="date" 
                      value={attendanceDate} 
                      onChange={e => setAttendanceDate(e.target.value)}
                      className="px-4 py-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                    <Button onClick={handleSaveAttendance}>Save Changes</Button>
                  </div>
                </div>

                <Card>
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 border-b border-slate-100">
                      <tr>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Student</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {students.map(student => (
                        <tr key={student.id}>
                          <td className="px-6 py-4">
                            <p className="font-semibold text-slate-900">{student.name}</p>
                            <p className="text-xs text-slate-500">{student.student_id}</p>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex gap-2">
                              {(['Present', 'Absent', 'Late'] as const).map(status => (
                                <button 
                                  key={status}
                                  onClick={() => setAttendanceRecords({
                                    ...attendanceRecords,
                                    [student.id]: status
                                  })}
                                  className={cn(
                                    "px-3 py-1 rounded-lg text-xs font-bold border transition-all",
                                    attendanceRecords[student.id] === status
                                      ? (status === 'Present' ? "bg-emerald-600 text-white border-emerald-600" :
                                         status === 'Absent' ? "bg-rose-600 text-white border-rose-600" :
                                         "bg-amber-600 text-white border-amber-600")
                                      : (status === 'Present' ? "border-emerald-200 text-emerald-600 hover:bg-emerald-50" :
                                         status === 'Absent' ? "border-rose-200 text-rose-600 hover:bg-rose-50" :
                                         "border-amber-200 text-amber-600 hover:bg-amber-50")
                                  )}
                                >
                                  {status}
                                </button>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </Card>
              </motion.div>
            )}

            {activeTab === 'timetable' && (
              <motion.div 
                key="timetable"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Timetable Management</h2>
                    <p className="text-slate-500">Schedule classes and manage sessions</p>
                  </div>
                  <Button onClick={() => setIsTimetableModalOpen(true)}>
                    <Plus size={20} />
                    Add Schedule
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="md:col-span-1 space-y-4">
                    <Card className="p-4">
                      <h3 className="font-bold text-slate-900 mb-4">Select Class</h3>
                      <div className="space-y-2">
                        {['Class 10', 'Class 11', 'Class 12'].map(cls => (
                          <button 
                            key={cls}
                            onClick={() => {
                              setTimetableFormData({...timetableFormData, class: cls});
                              fetchTimetable(cls);
                            }}
                            className={cn(
                              "w-full text-left p-3 rounded-lg transition-colors",
                              timetableFormData.class === cls ? "bg-indigo-600 text-white" : "hover:bg-slate-100 text-slate-600"
                            )}
                          >
                            {cls}
                          </button>
                        ))}
                      </div>
                    </Card>
                  </div>

                  <div className="md:col-span-3">
                    <Card>
                      <div className="grid grid-cols-5 border-b border-slate-100 bg-slate-50">
                        {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map(day => (
                          <div key={day} className="p-4 text-center font-bold text-xs text-slate-500 uppercase tracking-wider border-r border-slate-100 last:border-0">
                            {day}
                          </div>
                        ))}
                      </div>
                      <div className="grid grid-cols-5 min-h-[400px]">
                        {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map(day => (
                          <div key={day} className="border-r border-slate-100 last:border-0 p-2 space-y-2">
                            {timetable.filter(t => t.day === day).map(entry => (
                              <div key={entry.id} className="p-3 bg-indigo-50 border border-indigo-100 rounded-lg text-xs">
                                <p className="font-bold text-indigo-900">{entry.subject}</p>
                                <p className="text-indigo-600 mt-1">{entry.start_time} - {entry.end_time}</p>
                                <p className="text-slate-500 mt-1 italic">{entry.teacher}</p>
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                    </Card>
                  </div>
                </div>

                <AnimatePresence>
                  {isTimetableModalOpen && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="w-full max-w-md"
                      >
                        <Card className="p-6">
                          <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xl font-bold text-slate-900">Add Schedule Entry</h3>
                            <button onClick={() => setIsTimetableModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600">
                              <X size={20} />
                            </button>
                          </div>

                          <form onSubmit={handleAddTimetable} className="space-y-4">
                            <Select 
                              label="Class" 
                              options={[{value: 'Class 10', label: 'Class 10'}, {value: 'Class 11', label: 'Class 11'}, {value: 'Class 12', label: 'Class 12'}]} 
                              value={timetableFormData.class}
                              onChange={e => setTimetableFormData({...timetableFormData, class: e.target.value})}
                            />
                            <Input 
                              label="Subject" 
                              placeholder="Physics" 
                              value={timetableFormData.subject}
                              onChange={e => setTimetableFormData({...timetableFormData, subject: e.target.value})}
                              required
                            />
                            <Select 
                              label="Day" 
                              options={['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map(d => ({value: d, label: d}))} 
                              value={timetableFormData.day}
                              onChange={e => setTimetableFormData({...timetableFormData, day: e.target.value})}
                            />
                            <div className="grid grid-cols-2 gap-4">
                              <Input 
                                label="Start Time" 
                                type="time" 
                                value={timetableFormData.start_time}
                                onChange={e => setTimetableFormData({...timetableFormData, start_time: e.target.value})}
                                required
                              />
                              <Input 
                                label="End Time" 
                                type="time" 
                                value={timetableFormData.end_time}
                                onChange={e => setTimetableFormData({...timetableFormData, end_time: e.target.value})}
                                required
                              />
                            </div>
                            <Input 
                              label="Teacher" 
                              placeholder="Dr. Smith" 
                              value={timetableFormData.teacher}
                              onChange={e => setTimetableFormData({...timetableFormData, teacher: e.target.value})}
                              required
                            />
                            <div className="flex justify-end gap-3 mt-6">
                              <Button variant="secondary" type="button" onClick={() => setIsTimetableModalOpen(false)}>Cancel</Button>
                              <Button type="submit">Save Entry</Button>
                            </div>
                          </form>
                        </Card>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {activeTab === 'reports' && (
              <motion.div 
                key="reports"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Reports & Analytics</h2>
                    <p className="text-slate-500">Generate and view system reports</p>
                  </div>
                  <Button variant="secondary" onClick={() => window.print()}>
                    <FileText size={20} />
                    Print Summary
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <Card className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="p-3 bg-indigo-100 text-indigo-600 rounded-xl">
                        <Users size={24} />
                      </div>
                      <h3 className="font-bold text-slate-900">Student Report</h3>
                    </div>
                    <p className="text-sm text-slate-500 mb-6">Detailed list of all registered students with their enrollment status and contact info.</p>
                    <Button variant="secondary" className="w-full">Generate PDF</Button>
                  </Card>

                  <Card className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
                        <Calendar size={24} />
                      </div>
                      <h3 className="font-bold text-slate-900">Attendance Report</h3>
                    </div>
                    <p className="text-sm text-slate-500 mb-6">Monthly and weekly attendance summaries for all classes and individual students.</p>
                    <Button variant="secondary" className="w-full">Generate PDF</Button>
                  </Card>

                  <Card className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="p-3 bg-amber-100 text-amber-600 rounded-xl">
                        <GraduationCap size={24} />
                      </div>
                      <h3 className="font-bold text-slate-900">Academic Results</h3>
                    </div>
                    <p className="text-sm text-slate-500 mb-6">Consolidated marks sheets and performance analytics for the current semester.</p>
                    <Button variant="secondary" className="w-full">Generate PDF</Button>
                  </Card>
                </div>

                <Card className="p-6">
                  <h3 className="font-bold text-slate-900 mb-6">Recent System Activity</h3>
                  <div className="space-y-4">
                    {[
                      { action: 'New student registered', user: 'Admin', time: '2 hours ago' },
                      { action: 'Attendance marked for Class 10', user: 'Staff', time: '4 hours ago' },
                      { action: 'Fee payment recorded', user: 'Admin', time: 'Yesterday' },
                      { action: 'Marks updated for Physics', user: 'Teacher', time: '2 days ago' }
                    ].map((activity, i) => (
                      <div key={i} className="flex items-center justify-between py-3 border-b border-slate-50 last:border-0">
                        <div className="flex items-center gap-3">
                          <div className="w-2 h-2 rounded-full bg-indigo-500" />
                          <p className="text-slate-700 font-medium">{activity.action}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-slate-500">{activity.user}</p>
                          <p className="text-[10px] text-slate-400 uppercase">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            )}
            {activeTab === 'marks' && (
              <motion.div 
                key="marks"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Marks & Results</h2>
                    <p className="text-slate-500">Manage student academic performance</p>
                  </div>
                  <Button onClick={() => setIsMarkModalOpen(true)}>
                    <Plus size={20} />
                    Add Marks
                  </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <Card className="lg:col-span-1">
                    <div className="p-4 border-b border-slate-100">
                      <h3 className="font-bold text-slate-900">Select Student</h3>
                    </div>
                    <div className="divide-y divide-slate-100 max-h-[500px] overflow-y-auto">
                      {students.map(student => (
                        <button 
                          key={student.id}
                          onClick={() => {
                            setMarkFormData({...markFormData, student_id: student.id});
                            fetchMarks(student.id);
                          }}
                          className={cn(
                            "w-full text-left p-4 hover:bg-slate-50 transition-colors",
                            markFormData.student_id === student.id ? "bg-indigo-50 border-r-4 border-indigo-600" : ""
                          )}
                        >
                          <p className="font-semibold text-slate-900">{student.name}</p>
                          <p className="text-xs text-slate-500">{student.student_id}</p>
                        </button>
                      ))}
                    </div>
                  </Card>

                  <Card className="lg:col-span-2">
                    <div className="p-4 border-b border-slate-100">
                      <h3 className="font-bold text-slate-900">Academic Records</h3>
                    </div>
                    {markFormData.student_id === 0 ? (
                      <div className="p-20 text-center text-slate-400">
                        <GraduationCap size={48} className="mx-auto mb-4 opacity-20" />
                        <p>Select a student to view marks</p>
                      </div>
                    ) : (
                      <table className="w-full text-left">
                        <thead className="bg-slate-50 border-b border-slate-100">
                          <tr>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Subject</th>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Exam</th>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Marks</th>
                            <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Result</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {marks.map(mark => (
                            <tr key={mark.id}>
                              <td className="px-6 py-4 font-medium text-slate-900">{mark.subject}</td>
                              <td className="px-6 py-4 text-slate-600">{mark.exam_type}</td>
                              <td className="px-6 py-4">
                                <span className="font-bold text-slate-900">{mark.marks_obtained}</span>
                                <span className="text-slate-400"> / {mark.total_marks}</span>
                              </td>
                              <td className="px-6 py-4">
                                <span className={cn(
                                  "px-2 py-0.5 rounded text-xs font-bold",
                                  (mark.marks_obtained / mark.total_marks) >= 0.4 ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                                )}>
                                  {(mark.marks_obtained / mark.total_marks) >= 0.4 ? 'PASS' : 'FAIL'}
                                </span>
                              </td>
                            </tr>
                          ))}
                          {marks.length === 0 && (
                            <tr>
                              <td colSpan={4} className="px-6 py-10 text-center text-slate-400 italic">No records found for this student</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    )}
                  </Card>
                </div>

                <AnimatePresence>
                  {isMarkModalOpen && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="w-full max-w-md"
                      >
                        <Card className="p-6">
                          <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xl font-bold text-slate-900">Add Academic Mark</h3>
                            <button onClick={() => setIsMarkModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600">
                              <X size={20} />
                            </button>
                          </div>

                          <form onSubmit={handleAddMark} className="space-y-4">
                            <Select 
                              label="Student" 
                              options={students.map(s => ({ value: s.id.toString(), label: s.name }))}
                              value={markFormData.student_id}
                              onChange={e => setMarkFormData({...markFormData, student_id: parseInt(e.target.value)})}
                              required
                            />
                            <Input 
                              label="Subject" 
                              placeholder="Mathematics" 
                              value={markFormData.subject}
                              onChange={e => setMarkFormData({...markFormData, subject: e.target.value})}
                              required
                            />
                            <Select 
                              label="Exam Type" 
                              options={[{value: 'Midterm', label: 'Midterm'}, {value: 'Final', label: 'Final'}, {value: 'Quiz', label: 'Quiz'}]} 
                              value={markFormData.exam_type}
                              onChange={e => setMarkFormData({...markFormData, exam_type: e.target.value})}
                            />
                            <div className="grid grid-cols-2 gap-4">
                              <Input 
                                label="Marks Obtained" 
                                type="number" 
                                value={markFormData.marks_obtained}
                                onChange={e => setMarkFormData({...markFormData, marks_obtained: parseInt(e.target.value)})}
                                required
                              />
                              <Input 
                                label="Total Marks" 
                                type="number" 
                                value={markFormData.total_marks}
                                onChange={e => setMarkFormData({...markFormData, total_marks: parseInt(e.target.value)})}
                                required
                              />
                            </div>
                            <Input 
                              label="Exam Date" 
                              type="date" 
                              value={markFormData.date}
                              onChange={e => setMarkFormData({...markFormData, date: e.target.value})}
                              required
                            />
                            <div className="flex justify-end gap-3 mt-6">
                              <Button variant="secondary" type="button" onClick={() => setIsMarkModalOpen(false)}>Cancel</Button>
                              <Button type="submit">Save Record</Button>
                            </div>
                          </form>
                        </Card>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}

            {activeTab === 'fees' && (
              <motion.div 
                key="fees"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">Fee Management</h2>
                    <p className="text-slate-500">Track and manage student payments</p>
                  </div>
                  <Button onClick={() => setIsFeeModalOpen(true)}>
                    <Plus size={20} />
                    Record Payment
                  </Button>
                </div>

                <Card>
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 border-b border-slate-100">
                      <tr>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Student</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Amount</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {fees.map(fee => (
                        <tr key={fee.id}>
                          <td className="px-6 py-4">
                            <p className="font-semibold text-slate-900">{fee.name}</p>
                            <p className="text-xs text-slate-500">{fee.sid}</p>
                          </td>
                          <td className="px-6 py-4 font-bold text-slate-900">${fee.amount}</td>
                          <td className="px-6 py-4">
                            <span className={cn(
                              "px-2.5 py-1 rounded-full text-xs font-bold",
                              fee.status === 'Paid' ? "bg-emerald-100 text-emerald-700" :
                              fee.status === 'Pending' ? "bg-amber-100 text-amber-700" :
                              "bg-rose-100 text-rose-700"
                            )}>
                              {fee.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-600">{fee.payment_date || 'N/A'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </Card>

                <AnimatePresence>
                  {isFeeModalOpen && (
                    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="w-full max-w-md"
                      >
                        <Card className="p-6">
                          <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xl font-bold text-slate-900">Record Fee Payment</h3>
                            <button onClick={() => setIsFeeModalOpen(false)} className="p-2 text-slate-400 hover:text-slate-600">
                              <X size={20} />
                            </button>
                          </div>

                          <form onSubmit={handleAddFee} className="space-y-4">
                            <Select 
                              label="Select Student" 
                              options={students.map(s => ({ value: s.id.toString(), label: `${s.name} (${s.student_id})` }))}
                              value={feeFormData.student_id}
                              onChange={e => setFeeFormData({...feeFormData, student_id: parseInt(e.target.value)})}
                              required
                            />
                            <Input 
                              label="Amount ($)" 
                              type="number" 
                              value={feeFormData.amount}
                              onChange={e => setFeeFormData({...feeFormData, amount: parseFloat(e.target.value)})}
                              required
                            />
                            <Select 
                              label="Status" 
                              options={[{value: 'Paid', label: 'Paid'}, {value: 'Pending', label: 'Pending'}, {value: 'Overdue', label: 'Overdue'}]} 
                              value={feeFormData.status}
                              onChange={e => setFeeFormData({...feeFormData, status: e.target.value as any})}
                            />
                            <Input 
                              label="Payment Date" 
                              type="date" 
                              value={feeFormData.payment_date}
                              onChange={e => setFeeFormData({...feeFormData, payment_date: e.target.value})}
                            />
                            <Input 
                              label="Description" 
                              value={feeFormData.description}
                              onChange={e => setFeeFormData({...feeFormData, description: e.target.value})}
                            />
                            <div className="flex justify-end gap-3 mt-6">
                              <Button variant="secondary" type="button" onClick={() => setIsFeeModalOpen(false)}>Cancel</Button>
                              <Button type="submit">Save Payment</Button>
                            </div>
                          </form>
                        </Card>
                      </motion.div>
                    </div>
                  )}
                </AnimatePresence>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}
