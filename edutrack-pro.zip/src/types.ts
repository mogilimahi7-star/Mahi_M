import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export interface User {
  id: number;
  username: string;
  role: 'admin' | 'staff';
}

export interface Student {
  id: number;
  student_id: string;
  name: string;
  email: string;
  phone: string;
  dob: string;
  gender: string;
  address: string;
  class: string;
  section: string;
  enrollment_date: string;
}

export interface Attendance {
  id: number;
  student_id: number;
  date: string;
  status: 'Present' | 'Absent' | 'Late';
  name?: string;
  sid?: string;
}

export interface Mark {
  id: number;
  student_id: number;
  subject: string;
  exam_type: string;
  marks_obtained: number;
  total_marks: number;
  date: string;
}

export interface Fee {
  id: number;
  student_id: number;
  amount: number;
  status: 'Paid' | 'Pending' | 'Overdue';
  payment_date: string;
  description: string;
  name?: string;
  sid?: string;
}

export interface TimetableEntry {
  id: number;
  class: string;
  day: string;
  subject: string;
  start_time: string;
  end_time: string;
  teacher: string;
}
